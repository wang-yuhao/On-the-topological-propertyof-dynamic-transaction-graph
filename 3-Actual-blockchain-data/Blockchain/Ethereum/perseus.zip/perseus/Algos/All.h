/*
 * All.h
 *
 *  Created on: Jul 17, 2010
 *      Author: vidit nanda
 */

#ifndef ALL_ALGO_H_
#define ALL_ALGO_H_

#include "MorseReduction.hpp"
#include "PersistenceRoutines.hpp"


#endif /* ALL_H_ */
